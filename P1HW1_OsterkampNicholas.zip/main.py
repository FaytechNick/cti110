user_num = int(input('Enter integer:\n'))

print("You entered:", user_num)

squared = user_num * user_num
cubed = user_num * user_num * user_num

print(user_num, "squared is", squared)
print("And", user_num, "cubed is", cubed, "!!")

user_num2 = int(input("Enter another integer:\n"))

sum_nums = user_num + user_num2
product_nums = user_num * user_num2

print(user_num, "+", user_num2, "is", sum_nums)
print(user_num, "*", user_num2, "is", product_nums)